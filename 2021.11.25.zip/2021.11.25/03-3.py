# 3. Írj egy programot, ami a for ciklus használatával az alábbi szöveget írja ki
# Az év 1. hónapja január.
# Az év 2. hónapja február.
honapok = ["Az év 1. hónapja Január", "Az év 2. hónapja Február", "Az év 3. hónapja Március", "Az év 4. hónapja Április", "Az év 5. hónapja Május", "Az év 6. hónapja Június", "Az év 7. hónapja Július", "Az év 8. hónapja Augusztus", "Az év 9. hónapja Szeptember", "Az év 10. hónapja Október", "Az év 11. hónapja November", "Az év 12. hónapja December"]
for i in honapok:
    print(i)