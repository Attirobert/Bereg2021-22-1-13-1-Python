#4. Tételezzük fel, hogy a teknőcünk Eszti a 0 irányban áll – kelet felé néz. Végrehajtjuk az Eszti.left(3645) utasítást. Mit csinál Eszti és merre néz?

import turtle
ablak = turtle.Screen()
Eszti = turtle.Turtle()
Eszti.left(3645)
print("10 kört fordul balra, majd Észak-Kelet felé néz.")