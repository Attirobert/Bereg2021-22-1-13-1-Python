# 1. Írj egy programot, amely 1000-szer kiírja a Szeretjük a Python teknőcöket! mondatot!
a = 1000
for i in range(a):
    print("Szeretjük a Python teknőcöket!")