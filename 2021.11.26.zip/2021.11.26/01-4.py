# 4. Indítsd el a Python értelmezot, és gépeld be a ˝ Pista + 4 kifejezést, majd üss egy Entert. Az alábbi hiba
# jelenik meg:
# NameError: name 'Pista' is not defined
# Rendelj olyan értéket Pista változóhoz, hogy a Pista + 4 kifejezés értéke 10 legyen.
