#1. Tárold el a Lustaság fél egészség. mondat minden szavát külön változóban, majd jelenítsd meg egy sorba a
#print függvény használatával.
a = "Lustaság"
b = "Fél"
c = "egészség"
print(a,b,c)
