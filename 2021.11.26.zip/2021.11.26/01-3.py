# 3. Tegyél megjegyzés jelet egy olyan sor elé, amely korábban már m ˝uködött. Figyeld meg, mi történik, amikor
# újra futtatod a programot!
#a = 6*(1-2)
print(a)