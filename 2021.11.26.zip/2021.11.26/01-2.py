#2. Zárójelezd úgy a 6 * 1 - 2 kifejezést, hogy a 4 helyett -6 legyen az értéke.
a = 6*(1-2)
print(a)